<?php
// Verificar las credenciales (esto es solo un ejemplo básico, no es seguro en producción)
$usuario_valido = 'usuario'; // Cambia estos valores con tus propias credenciales
$contrasena_valida = 'contrasena';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['username'];
    $contrasena = $_POST['password'];

    if ($usuario === $usuario_valido && $contrasena === $contrasena_valida) {
        // Inicio de sesión exitoso, redirige o realiza otras acciones
        echo 'Inicio de sesión exitoso. Bienvenido, ' . $usuario . '!';
    } else {
        // Credenciales incorrectas, manejar el error apropiadamente
        echo 'Credenciales incorrectas. Inténtalo de nuevo.';
    }
}
?>